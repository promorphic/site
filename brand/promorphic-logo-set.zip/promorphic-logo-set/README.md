Promorphic mark and wordmark. Blocks are `ink` for the ground named in the file (`on-dark`: #f2efe8, `on-light`: #14130f); the bar is always `brand` #f2b135. Mono variants are one ink (black or white) for print, embossing and third-party listings that allow a single colour. `promorphic-tile.svg` is the app-icon and avatar form: mark at 56% on a #0b0c0e square with a 12.5% radius; use it wherever the ground is unknown or below 16px. `favicon.svg` swaps its ink with `prefers-color-scheme` and is the site's favicon; `og-image.png` is the 1200×630 share card, drawn in the X header's language (headline set low, the exploded mark as a block cluster beside it, the amber bar running off the right edge, the row of six blocks): headline "Agentic Infrastructure For Tokenized Assets.", line beneath "AI treasury manager for onchain asset managers", then promorphic.xyz. Generator: `design/logo/og_card.py`. Venue wordmarks are not ours and are not kept here: they live in the site repo under `brand/venues/` with their sources. Clear space: one bar-height on every side. Minimum: 16px mark, 96px wordmark.

Raster copies (PNG, JPEG) of every file at the recommended sizes live in the site repo under `brand/logo/png` and `brand/logo/jpg`, generated from these SVGs by `preview/streams-v4/rasters.py`; regenerate them whenever an SVG changes.


## Rasters

`svg/` holds the masters. `png/` has every mark at 128, 256, 512 and 1024px (transparent), the tile at
180, 192, 512 and 1024px (app icons, apple-touch-icon, favicons) and every wordmark at 600, 1200 and
2400px wide. `jpg/` has the same marks at 512 and 1024px and the wordmarks at 1200 and 2400px on their
own ground: light files on #f7f5f0, dark files on #0b0c0e, the tile on #0b0c0e. Use PNG wherever
transparency is possible and JPEG only where it is not (some listing forms, slide tools, email).
